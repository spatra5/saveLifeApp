app.controller('authCtrl', function ($scope, $rootScope, $routeParams, $location, $http, Data) {
    //initially set those objects to null to avoid undefined error
    $scope.login = {};
    $scope.signup = {};

    $scope.doLogin = function (customer) {
        Data.post('login', {
            customer: customer
        }).then(function (results) {
            Data.toast(results);
            if (results.status == "success") {
                $location.path('home');
            }
        });
    };
    $scope.userTypeList = ['Caregiver','Doctor'];

    $scope.signup = {email:'',password:'',name:'',phone:'',address:''};
    $scope.signup.utype = angular.copy($scope.userTypeList[0]);
    $scope.signup.kiosk = '';
    $scope.signUp = function (customer) {
        $scope.signup.kiosk = $rootScope.kiosk;
        Data.post('signUp', {
            customer: customer
        }).then(function (results) {
            Data.toast(results);
            $scope.signup = {email:'',password:'',name:'',phone:'',address:''};
            // if (results.status == "success") {
            //     $location.path('home');
            // }
        });
    };

    $scope.logout = function () {
        Data.get('logout').then(function (results) {
            Data.toast(results);
            $location.path('login');
        });
    };

    $scope.initDashboard = function () {

    };

    $scope.addPatient = function (kiosk) {
      if($scope.userKiosk === null) {
        var url = 'kiosk?kid=' + kiosk;
        Data.get(url).then(function (results) {
            $scope.userKiosk = {
              id: kiosk,
              details: results
            };

            console.log('addPatientif', $scope.newPatient, kiosk, $scope.userKiosk);
            var patient = angular.copy($scope.newPatient);
            patient.kid = $scope.userKiosk.id;
            patient.dcode= $scope.userKiosk.details.dcode;
            patient.createdby = $rootScope.uid;

            Data.post('patient', {
                patient: patient
            }).then(function (results) {
                Data.toast(results);
                $scope.patientsList = null;
                $scope.getPatients(kiosk);
                $scope.newPatient = {
                  name: '',
                  age: '',
                  phone: '',
                  payment: ''
                };
            });


        });
      }
      else {
        console.log('addPatientelse', $scope.newPatient, kiosk, $scope.userKiosk);
        var patient = angular.copy($scope.newPatient);
        patient.kid = $scope.userKiosk.id;
        patient.dcode= $scope.userKiosk.details.dcode;
        patient.createdby = $rootScope.uid;

        Data.post('patient', {
            patient: patient
        }).then(function (results) {
            Data.toast(results);
            $scope.patientsList = null;
            $scope.getPatients(kiosk);
            $scope.newPatient = {
              name: '',
              age: '',
              phone: '',
              payment: ''
            };
        });
      }
      angular.element('#addPatientModal .close').click();
    };


    $scope.newPatient = {
      name: '',
      age: '',
      phone: '',
      payment: ''
    };
    //$scope.addPatient($scope.newPatient);

    $scope.getAllKiosk = function () {
      var url = 'kiosks';
      Data.get(url).then(function (results) {
          $scope.kiosksList = results;
      });
    };
    $scope.userKiosk = null;
    $scope.getKiosk = function (kid) {
      if($scope.userKiosk === null) {
        var url = 'kiosk?kid=' + kid;
        Data.get(url).then(function (results) {
          if(results !== null) {
            $scope.userKiosk = {
              id: kid,
              details: results
            };
          }
          else {
            $scope.userKiosk = null;
          }
        });
      }
    };

    $scope.patientsList = null;
    $scope.getPatients = function (param) {
      if($scope.patientsList === null) {
        var url = 'patients?param=' + param;
        Data.get(url).then(function (results) {
            $scope.patientsList = results;
        });
      }
    };

    var getIndexOfObjectInList = function(list, objectProp, objectVal) {
      for(var i = 0; i < list.length; i++) {
        //console.log(list[i][objectProp] , objectVal, list[i][objectProp] == objectVal);
        if(list[i][objectProp] == objectVal) {
          return i;
        }
      }
      return -1;
    };

    $scope.doctorsList = null;
    $scope.getDoctors = function (kid) {
      if($scope.doctorsList === null) {
        var url = 'doctors?kid=' + kid;
        Data.get(url).then(function (results) {
          $scope.doctorsList = [];
          var doctorObj = {}
          angular.forEach(results, function(doctor){
            var doctorIndex = getIndexOfObjectInList($scope.doctorsList, "uid", doctor.uid);
            if(doctorIndex == -1) {
              var doctorObj = {
                uid: doctor.uid,
                name: doctor.name,
                email: doctor.email,
                phone: doctor.phone,
                patients: []
              };
              if(doctor.pid !== null && doctor.status == 'Pending') {
                doctorObj.patients.push({ pid: doctor.pid, paid: doctor.paid });
              }
              $scope.doctorsList.push(doctorObj);
            }
            else {
              if(doctor.pid !== null) {
                $scope.doctorsList[doctorIndex].patients.push(doctor.pid);
              }
            }
          });
          console.log('$scope.doctorsList', $scope.doctorsList);

        });
      }
    };

    $scope.getDoctor = function (uid) {
      var url = 'users?uid=' + uid;
      Data.get(url).then(function (results) {
          $scope.currentPatient.doctor = results;
      });
    };

    $scope.caregiversList = null;
    $scope.getCaregivers = function (kid) {
      if($scope.caregiversList === null) {
        var url = 'caregivers?kid=' + kid;
        Data.get(url).then(function (results) {
            $scope.caregiversList = results;
        });
      }
    };

    $scope.getReports = function (pid) {
      var url = 'reports?pid=' + pid;
      Data.get(url).then(function (results) {
          console.log('patientReportsList', results);
          $scope.patientReportsList = results;
      });
    };
    $scope.newReport = {
      report: '',
      pfile: '',
      ecgfile: ''
    };

    $scope.addReport = function (pid) {
      console.log('Add report to', pid, $scope.newReport.pfile);
      // if($scope.newReport.pfile === '' || $scope.newReport.pfile.type.indexOf("audio/") === -1) {
      //   $scope.ptReportError = 'Please select an audio file for Heart Sound.';
      // }
      // else if($scope.newReport.ecgfile === '' || $scope.newReport.ecgfile.type.indexOf("image/") === -1) {
      //   $scope.ptReportError = 'Please select an image file for ECG.';
      // }
      // else
      if($scope.newReport.pfile.size/1024/1024 > 10) {
        $scope.ptReportError = 'Please select an audio file of size upto 10MB.';
      }
      else if($scope.newReport.ecgfile.size/1024/1024 > 10) {
        $scope.ptReportError = 'Please select an image file of size upto 10MB.';
      }
      else {
        $scope.ptReportError = '';
        var newReport = angular.copy($scope.newReport.report);
        console.log('newReport', newReport);
        var report = {
          pid: pid,
          report: {
            bp: newReport.bp.low + '/' + newReport.bp.high,
            pulse: newReport.pulse,
            oxygen: newReport.oxygen,
            temp: newReport.temp,
            height: newReport.height,
            weight: newReport.weight,
            symptoms: JSON.stringify(newReport.symptoms),
            createdby: $rootScope.uid
          }
        };
        //report.report.createdby = $rootScope.uid;

        Data.upload('report', {
            report: report
        },$scope.newReport.pfile, $scope.newReport.ecgfile).then(function (results) {
          $scope.newReport = {
            report: '',
            pfile: '',
            ecgfile: ''
          };
          Data.toast(results);
          $scope.patientReportsList = null;
          $scope.getReports(pid);
          angular.element('#ptReportFormModal .close').click();
        });
      }


    };

    $scope.navigatePatient = function (patient) {
      $rootScope.currentPatient = patient;
      $location.path('patient');
    };

    $scope.initPatient = function () {
      if(!$rootScope.currentPatient) {
        $location.path('dashboard');
      }
    };

    $scope.downloadFile = function (type, fileId, action) {
      var url = 'api/v1/report?rid=' + fileId + '&type=' + type + '&action=' + action;
      return url;
    };

    $scope.selectTab = function (tab) {
      $scope.selectedTab = tab;
    };

    $scope.selectedTab = 'userDetails';
    $scope.getPtReport = function (report) {
      $scope.currentReport = report;
    };

    $scope.ptAddDoctor = function () {
      console.log($scope.currentPatient.doctor);
      Data.post('patient/assign', {
          params: {
            pid: $scope.currentPatient.pid,
            docid: $scope.currentPatient.doctor.uid,
            createdby: $rootScope.uid
          }
      }).then(function (results) {
          Data.toast(results);
          if(results) {
            $scope.currentPatient.docid = results.docid;
          }
      });
      angular.element('#ptAddDoctorModal .close').click();
    };

    $scope.newPrescription = {
      medicines: [
      ],
      diagnoses: [
      ]
    };

    $scope.deleteFromList = function(list, index) {
      list.splice(index, 1);
    };

    $scope.addNewDiagnosis = function (diagnoses) {
      var newDiagnosis = {
        id: '',
        desc: '',
        duedate: ''
      };
      newDiagnosis.id = diagnoses.length + 1;
      diagnoses.push(newDiagnosis);
    };

    $scope.addNewMedicine = function (medicines) {
      var newMedicine = {
        id: '',
        desc: '',
        dosage: '',
        days: '',
        quantity: ''
      };
      newMedicine.id = medicines.length + 1;
      medicines.push(newMedicine);
    };

    $scope.addPrescription = function () {
      var prescription = angular.copy($scope.newPrescription);

      var rows = [];
      rows.push(['SL#', 'Medicine Desc', 'Dosage', 'No of Days', 'Quantity']);

      angular.forEach(prescription.medicines, function(obj) {
          var row = [];
          angular.forEach(Object.keys(obj), function(key) {
            row.push(obj[key]);
          });
          rows.push(row);
      });

      var drows = [];
      drows.push(['SL#', 'Diagnosis Description', 'Duedate']);

      angular.forEach(prescription.diagnoses, function(obj) {
          var row = [];
          angular.forEach(Object.keys(obj), function(key) {
            row.push(obj[key]);
          });
          drows.push(row);
      });
      var currentReport = $scope.patientReportsList[0];

      var symptoms = '';
      angular.forEach($scope.getSymptoms(currentReport.symptoms), function(value) {
        symptoms+= value.toUpperCase() + ' ';
      });

      var docDef = { content: [
        { text: 'Prescription for Patient: ' + $scope.currentPatient.name + ' (' + $scope.currentPatient.pid + ')', style: 'header' },
        { text: 'Based on Report: RPT' + currentReport.rid },
        { text: 'Prescription Date: ' + new Date().toISOString().slice(0, 19)},
        { text: 'Prescribed By: ' + $rootScope.name},
        { text: 'Patient Medical Information: ', style: 'subheader' },
        {
    			alignment: 'justify',
    			columns: [
    				{
    					text: 'BP: ' +  currentReport.bp
            },
    				{
    					text: 'Temp: ' + currentReport.temp
            },
            {
    					text: 'Oxygen: ' +  currentReport.oxygen
            },
            {
    					text: 'Pulse: ' +  currentReport.pulse
            },
            {
    					text: 'Weight: ' +  currentReport.weight
            },
            {
    					text: 'Height: ' +  currentReport.height
            }
    			]
    		},
        { text: 'Patient Symptoms: ', style: 'subheader' },
        {
          text: symptoms
        },
        { text: 'Medicines:', style: 'subheader'},
        {
          style: 'tableExample',
          table: {
            headerRows: 1,
            widths: [ '*', '*', '*', '*', '*' ],
            body: rows
          }
        },
        { text: 'Diagnoses:', style: 'subheader'},
        {
          style: 'tableExample',
          table: {
            headerRows: 1,
            widths: [ '*', '*', '*' ],
            body: drows
          }
        },
        ],
        styles: {
      		header: {
      			fontSize: 18,
      			bold: true,
            alignment: 'center',
      			margin: [0, 0, 0, 10]
      		},
      		subheader: {
      			fontSize: 14,
      			bold: true,
      			margin: [0, 10, 0, 5]
      		},
      		tableExample: {
      			margin: [0, 15, 15, 15]
      		},
      		tableHeader: {
      			bold: true,
      			fontSize: 13,
      			color: 'black'
      		}
	       }

      };


      // open the PDF in a new window
      var pdf = pdfMake.createPdf(docDef);
      //pdf.open();
      var PDFdata;
      pdf.getDataUrl(function(dataURL) {
        PDFdata = dataURL;
        //console.log(PDFdata);
        var report = {
          pid: $scope.currentPatient.pid,
          prescription: PDFdata,
          createdby: $rootScope.uid,
          paid: $scope.currentPatient.paid
        };
        angular.element('#ptPrescFormModal .close').click();
        Data.post('prescription', {
          prescription: report
        }).then(function (results){
          Data.toast(results);
          $location.path('dashboard');
        })
      });

      //pdf.download();
      // pdfDoc is a stream so you can pipe it to the file system

      // pdf.getBuffer(function(buffer) {
      //     // turn buffer into blob
      //     var filedata = buffer;
      //     console.log('filedata', filedata);
      //
      //     Data.upload('prescription', {
      //         report: report
      //     }, filedata, null).then(function (results) {
      //
      //       Data.toast(results);
      //
      //     });
      // });

    };
    $scope.currentDate = new Date();
    $scope.getDistrictPtReports = function () {
      var url = 'reports/patients';
      Data.get(url).then(function (results) {
          //console.log('getDistrictPtReports', results);
          $scope.districtPtReports = results.result;
          //console.log($scope.districtPtReports.length);
      });
    };
    $scope.getAssignReports = function (kid) {
      var url = 'reports/assign?kid=' + kid;
      Data.get(url).then(function (results) {
          $scope.assignReportsList = results.result;
      });
    };

    $scope.getCaregiverReports = function (kid) {
      var url = 'reports/caregivers?kid=' + kid;
      Data.get(url).then(function (results) {
          $scope.cgReportsList = results.result;
      });
    };
    $scope.getPrescription = function (prescription) {
      window.open( prescription, '_blank');
    };
    $scope.patientPrescriptionsList = [];
    $scope.getPrescriptions = function (pid) {
      var url = 'prescriptions?pid=' + pid;
      Data.get(url).then(function (results) {
          console.log('patientPrescriptionList', results);
          $scope.patientPrescriptionList = results;
          console.log($scope.patientPrescriptionsList.length);
      });
    };
    $scope.getSymptoms = function (symptoms) {
      var symptoms = JSON.parse(symptoms);
      var symptomsList = [];
      angular.forEach(symptoms, function(value, key){
        symptomsList.push(key);
      });
      return symptomsList;
    }
});
