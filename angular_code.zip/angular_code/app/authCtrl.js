app.controller('authCtrl', function ($scope, $rootScope, $routeParams, $location, $http, Data) {
    //initially set those objects to null to avoid undefined error
    $scope.login = {};
    $scope.signup = {};

    $scope.doLogin = function (customer) {
        Data.post('login', {
            customer: customer
        }).then(function (results) {
            Data.toast(results);
            if (results.status == "success") {
                $location.path('home');
            }
        });
    };
    $scope.userTypeList = ['Caregiver','Doctor'];

    $scope.signup = {email:'',password:'',name:'',phone:'',address:''};
    $scope.signup.utype = angular.copy($scope.userTypeList[0]);
    $scope.signup.kiosk = '';
    $scope.signUp = function (customer) {
        Data.post('signUp', {
            customer: customer
        }).then(function (results) {
            Data.toast(results);
            if (results.status == "success") {
                $location.path('home');
            }
        });
    };
    $scope.logout = function () {
        Data.get('logout').then(function (results) {
            Data.toast(results);
            $location.path('login');
        });
    };

    $scope.addPatient = function (patient) {
        Data.post('patient', {
            patient: patient
        }).then(function (results) {
            Data.toast(results);
            // if (results.status == "success") {
            //     $location.path('home');
            // }
        });
    };

    $scope.newPatient = {
      name: 'Soma',
      age: 34,
      phone: Math.round(Math.random() * 10000000000, 10),
      kid: 'K001',
      dcode:'HGL'
    };
    //$scope.addPatient($scope.newPatient);

    $scope.getAllKiosk = function () {
      var url = 'kiosks';
      Data.get(url).then(function (results) {
          $scope.kiosksList = results;
      });
    };

    $scope.getKiosk = function (kid) {
      var url = 'kiosk?kid=' + kid;
      Data.get(url).then(function (results) {
          $scope.userKiosk = results;
      });
    };

    $scope.getPatients = function (kid) {
      var url = 'patients?kid=' + kid;
      Data.get(url).then(function (results) {
          $scope.patientsList = results;
      });
    };

    $scope.getDoctors= function (kid) {
      var url = 'doctors?kid=' + kid;
      Data.get(url).then(function (results) {
          $scope.doctorsList = results;
      });
    };

    $scope.getCaregivers = function (kid) {
      var url = 'caregivers?kid=' + kid;
      Data.get(url).then(function (results) {
          $scope.caregiversList = results;
      });
    };


    // $scope.init = function () {
    //   console.log('$r', $rootScope.kiosk);
    //   if($rootScope.kiosk) {
    //     $scope.getKiosk($rootScope.kiosk);
    //   }
    // };
});
