app.factory("Data", ['$http', 'toaster',
    function ($http, toaster) { // This service connects to our REST API

        var serviceBase = 'api/v1/';

        var obj = {};
        obj.toast = function (data) {
            toaster.pop(data.status, "", data.message, 3000, 'trustedHtml');
        }
        obj.get = function (q) {
            return $http.get(serviceBase + q).then(function (results) {
                return results.data;
            });
        };
        obj.post = function (q, object) {
            return $http.post(serviceBase + q, object).then(function (results) {
                return results.data;
            });
        };
        obj.put = function (q, object) {
            return $http.put(serviceBase + q, object).then(function (results) {
                return results.data;
            });
        };
        obj.delete = function (q) {
            return $http.delete(serviceBase + q).then(function (results) {
                return results.data;
            });
        };

        obj.upload = function (q, object, file, name) {
            console.log('object.report', object.report)
           var fd = new FormData();
           fd.append('file', file);
           fd.append('name', name);
           fd.append('robject', JSON.stringify(object));
           fd.append('report', object.report);
           fd.append('pid', object.pid);

            return $http.post(serviceBase + q, fd, {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined,'Process-Data': false}
            }).then(function (results) {
                console.log('data.js', results);
                return results.data;
            });
        };

        return obj;
}]);
