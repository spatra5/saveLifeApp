<?php
$app->get('/session', function() {
    $db = new DbHandler();
    $session = $db->getSession();
    $response["uid"] = $session['uid'];
    $response["utype"] = $session['utype'];
    $response["kiosk"] = $session['kiosk'];
    $response["email"] = $session['email'];
    $response["name"] = $session['name'];
    echoResponse(200, $session);
});

$app->get('/patients', function() use ($app) {
    $param = $paramValue = $app->request()->params('param');
    $db = new DbHandler();
    if ($param != NULL) {
      $patients = $db->getAllRecords("select pd.pid, pd.name, pd.age, pd.phone, pa.docid from patient_details as pd left join patient_assignments as pa on pd.pid = pa.pid where pd.pid like '%$param%'");
    }
    else {
      $patients = $db->getAllRecords("select pd.pid, pd.name, pd.age, pd.phone, pa.docid from patient_details as pd left join patient_assignments as pa on pd.pid = pa.pid");
    }
    echoResponse(200, $patients);
});

$app->get('/users', function() use ($app) {
    $uid = $paramValue = $app->request()->params('uid');
    $db = new DbHandler();
    if ($uid != NULL) {
      $users = $db->getOneRecord("select uid, name, email, phone from customers_auth where uid='$uid'");
    }
    else {
      $users = $db->getAllRecords("select uid, name, email, phone from customers_auth");
    }
    echoResponse(200, $users);
});

$app->get('/doctors', function() use ($app) {
    $kid = $paramValue = $app->request()->params('kid');
    $db = new DbHandler();
    if ($kid != NULL) {
      $doctors = $db->getAllRecords("select uid, name, email, phone from customers_auth where utype='Doctor' and kiosk='$kid'");
    }
    else {
      $doctors = $db->getAllRecords("select uid, name, email, phone from customers_auth where utype='Doctor'");
    }
    echoResponse(200, $doctors);
});

$app->get('/caregivers', function() use ($app) {
    $kid = $paramValue = $app->request()->params('kid');
    $db = new DbHandler();
    if ($kid != NULL) {
      $patients = $db->getAllRecords("select uid, name, email, phone from customers_auth where utype='Caregiver' and kiosk='$kid'");
    }
    else {
      $patients = $db->getAllRecords("select uid, name, email, phone from customers_auth where utype='Caregiver'");
    }
    echoResponse(200, $patients);
});

$app->get('/kiosks', function() {
    $db = new DbHandler();
    $kiosks = $db->getAllRecords("select kid,name,district from kiosk_details");
    echoResponse(200, $kiosks);
});

$app->get('/kiosk', function () use ($app) {
    $kid = $paramValue = $app->request()->params('kid');
    $db = new DbHandler();
    $kiosk = $db->getOneRecord("select k.name, d.dcode, d.dname from kiosk_details as k join district_details as d on k.district = d.dcode where k.kid='$kid'");
    echoResponse(200, $kiosk);
});

$app->post('/login', function() use ($app) {
    require_once 'passwordHash.php';
    $r = json_decode($app->request->getBody());
    verifyRequiredParams(array('email', 'password'),$r->customer);
    $response = array();
    $db = new DbHandler();
    $password = $r->customer->password;
    $email = $r->customer->email;
    $user = $db->getOneRecord("select uid,utype,name,password,email,kiosk,created from customers_auth where phone='$email' or email='$email'");
    if ($user != NULL) {
        if(passwordHash::check_password($user['password'],$password)){
        $response['status'] = "success";
        $response['message'] = 'Logged in successfully.';
        $response['user'] = $user;
        $response['uid'] = $user['uid'];
        $response['email'] = $user['email'];
        $response['createdAt'] = $user['created'];
        if (!isset($_SESSION)) {
            session_start();
        }
        $_SESSION['uid'] = $user['uid'];
        $_SESSION['email'] = $email;
        $_SESSION['name'] = $user['name'];
        $_SESSION['utype'] = $user['utype'];
        $_SESSION['kiosk'] = $user['kiosk'];

        } else {
            $response['status'] = "error";
            $response['message'] = 'Login failed. Incorrect credentials.';
        }
    }else {
            $response['status'] = "error";
            $response['message'] = 'No such user is registered.';
        }
    echoResponse(200, $response);
});
$app->post('/signUp', function() use ($app) {
    $response = array();
    $r = json_decode($app->request->getBody());
    verifyRequiredParams(array('email', 'name', 'password'),$r->customer);
    require_once 'passwordHash.php';
    $db = new DbHandler();

    $phone = $r->customer->phone;
    $name = $r->customer->name;
    $email = $r->customer->email;
    $address = $r->customer->address;
    $password = $r->customer->password;
    $utype = $r->customer->utype;
    $kiosk = $r->customer->kiosk;

    $isUserExists = $db->getOneRecord("select 1 from customers_auth where phone='$phone' or email='$email'");
    if(!$isUserExists){
        $r->customer->password = passwordHash::hash($password);
        $table_name = "customers_auth";
        $column_names = array('phone', 'name', 'email', 'password', 'address', 'utype', 'kiosk');
        $result = $db->insertIntoTable($r->customer, $column_names, $table_name);
        if ($result != NULL) {
            $response["status"] = "success";
            $response["message"] = "User account created successfully.";
            $response["uid"] = $result;
            if (!isset($_SESSION)) {
                session_start();
            }
            $_SESSION['uid'] = $response["uid"];
            $_SESSION['phone'] = $phone;
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['utype'] = $utype;
            $_SESSION['kiosk'] = $kiosk;

            echoResponse(200, $response);
        } else {
            $response["status"] = "error";
            $response["message"] = "Failed to create customer. Please try again.";
            echoResponse(201, $response);
        }
    }else{
        $response["status"] = "error";
        $response["message"] = "An user with the provided phone or email exists!";
        echoResponse(201, $response);
    }
});

$app->post('/patient', function() use ($app) {
    $response = array();
    $r = json_decode($app->request->getBody());
    verifyRequiredParams(array('name', 'age', 'phone'),$r->patient);

    $db = new DbHandler();

    $phone = $r->patient->phone;
    $dcode = $r->patient->dcode;
    $kid = $r->patient->kid;
    $age = $r->patient->age;
    $r->patient->age = intval($r->patient->age);

    $isUserExists = $db->getOneRecord("select 1 from patient_details where phone='$phone'");
    if(!$isUserExists){
        $patientCount = $db->getOneRecord("select patient_id as count from patient_id_count");
        $oldCount = $patientCount['count'];
        $count = intval($oldCount) + 1;
        $putCount = $db->updateRecord("update patient_id_count set patient_id='$count' WHERE patient_id='$oldCount'");


        $pid = $dcode . $kid . 'P' . $count;
        $r->patient->pid = $pid;

        $table_name = "patient_details";
        $column_names = array('phone', 'name', 'age', 'pid');
        $result = $db->insertIntoTable($r->patient, $column_names, $table_name);

        if($result === NULL) {
          $response["status"] = "error";
          $response["message"] = "Failed to add patient. Please try again.";
          echoResponse(201, $response);
        }
        else {
          $response["status"] = "success";
          $response["message"] = "Patient is added successfully.";
          $response["pid"] = $pid;
          echoResponse(200, $response);
        }

    }else{
        $response["status"] = "error";
        $response["message"] = "A patient with the provided phone exists!";
        echoResponse(201, $response);
    }
});

$app->get('/reports', function() use ($app) {
    $pid = $paramValue = $app->request()->params('pid');
    $db = new DbHandler();
    $reports = array();
    if ($pid != NULL) {
      $reports = $db->getAllRecords("select rid, pulse, bp, temp, oxygen, created from patient_reports where pid='$pid' ");
    }
    echoResponse(200, $reports);
});

$app->get('/report', function() use ($app) {
    $rid = $paramValue = $app->request()->params('rid');
    $type = $paramValue = $app->request()->params('type');
    $action = $paramValue = $app->request()->params('action');

    $db = new DbHandler();
    $reports = array();
    if ($rid != NULL) {
      $reports = $db->getOneRecord("select * from patient_reports where rid='$rid' ");
    }

    if ($type != NULL) {
      if($type == 'audio') {
        $filedata = $reports['soundfile'];
        $filetype = $reports['sfiletype'];
        $filename = 'RPTHS'.$rid.'.'.substr($filetype, strpos($filetype, "/") + 1);
      }
      else if($type == 'image') {
        $filedata = $reports['ecgfile'];
        $filetype = $reports['ecgfiletype'];
        $filename = 'RPTECG'.$rid.'.'.substr($filetype, strpos($filetype, "/") + 1);
      }

      $filesize = strlen($filedata);

      if($action == 'download') {
        header("Content-Length: $filesize");
        header("Content-Type: $filetype");
        header("Content-Disposition: attachment; filename=".$filename);
        echo $filedata;
      }
      else {
        $app->response->headers->set('Content-Type', $filetype);
        $app->response->headers->set('Pragma', "public");
        $app->response->headers->set('Content-Disposition:', 'attachment; filename=Report-'.$rid);
        $app->response->headers->set('Content-Transfer-Encoding', 'binary');
        $app->response->headers->set('Content-Length', $filesize);
        $app->response->setBody($filedata);
      }
    }

    //header("Content-Length: $filesize");
    // header("Content-Type: image/jpeg");
    // header("Content-Disposition: attachment; filename=Report-".$rid);
    // echo $filedata;
    //echoResponse(200, $filetype);
});

$app->post('/report', function() use ($app) {

    $response = array();
    $r = json_decode($_POST['robject']);

    verifyRequiredParams(array('pid'),$r->report);
    // $fileName = $_FILES['file2']['name'];
    // echoResponse(200, $fileName);

    $file = 'file1';
    $fileName = $_FILES[$file]['name'];
    $tmpName  = $_FILES[$file]['tmp_name'];
    $fileSize1 = $_FILES[$file]['size'];
    $fileType1 = $_FILES[$file]['type'];
    $fp      = fopen($tmpName, 'r');
    $content1 = fread($fp, filesize($tmpName));
    $content1 = addslashes($content1);
    fclose($fp);

    $file = 'file2';
    $fileName = $_FILES[$file]['name'];
    $tmpName  = $_FILES[$file]['tmp_name'];
    $fileSize2 = $_FILES[$file]['size'];
    $fileType2 = $_FILES[$file]['type'];
    $fp      = fopen($tmpName, 'r');
    $content2 = fread($fp, filesize($tmpName));
    $content2 = addslashes($content2);
    fclose($fp);
    // if(!get_magic_quotes_gpc())
    // {
    //     $fileName = addslashes($fileName);
    // }

    $pid = $r->report->pid;

    $report = $r->report->report;
    $report->soundfile = $content1;
    $report->ecgfile = $content2;
    $report->sfiletype = $fileType1;
    $report->ecgfiletype = $fileType2;
    $report->pid = $pid;
    //echoResponse(200, $report);


    $db = new DbHandler();



    $isUserExists = $db->getOneRecord("select 1 from patient_details where pid='$pid'");
    if($isUserExists){

        $table_name = "patient_reports";
        $column_names = array('pid', 'soundfile', 'sfiletype', 'ecgfile', 'ecgfiletype', 'pulse', 'bp', 'temp', 'oxygen');
        $result = $db->insertIntoTable($report, $column_names, $table_name);

        if($result === NULL) {
          $response["status"] = "error";
          $response["message"] = "Failed to create patient's report. Please try again.";
          echoResponse(201, $response);
        }
        else {
          $response["status"] = "success";
          $response["message"] = "Patient's report is created successfully.";
          $response["pid"] = $pid;
          $response["rid"] = $result;
          echoResponse(200, $response);
        }

    }
    else{
        $response["status"] = "error";
        $response["message"] = "No patient with the data provided exists!";
        echoResponse(201, $response);
    }


});

$app->post('/patient/assign', function() use ($app) {
    $response = array();
    $r = json_decode($app->request->getBody());
    verifyRequiredParams(array('pid', 'docid'),$r->params);
    $pid = $r->params->pid;
    $docid = $r->params->docid;

    $db = new DbHandler();
    $isUserExists = $db->getOneRecord("select 1 from patient_assignments where pid='$pid'");

    if(!$isUserExists) {
      $table_name = "patient_assignments";
      $column_names = array('pid', 'docid');
      $result = $db->insertIntoTable($r->params, $column_names, $table_name);

      if($result === NULL) {
        $response["status"] = "error";
        $response["message"] = "Failed to assign Doctor. Please try again.";
        echoResponse(201, $response);
      }
      else {
        $response["status"] = "success";
        $response["message"] = "Doctor is assigned to the patient successfully.";
        $response["pid"] = $pid;
        $response["docid"] = $docid;
        echoResponse(200, $response);
      }
    }
});

$app->get('/logout', function() {
    $db = new DbHandler();
    $session = $db->destroySession();
    $response["status"] = "info";
    $response["message"] = "Logged out successfully.";
    echoResponse(200, $response);
});
?>
