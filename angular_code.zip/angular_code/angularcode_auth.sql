DROP DATABASE IF EXISTS angularcode;
CREATE DATABASE IF NOT EXISTS angularcode;

USE angularcode;

--
-- Table structure for table `customers_auth`
--

CREATE TABLE IF NOT EXISTS `customers_auth` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `utype` varchar(50),
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `address` varchar(50) NOT NULL,
  `kiosk` varchar(5) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=187 ;

--
-- Dumping data for table `customers_auth`
--

INSERT INTO `customers_auth` (`uid`, `utype`, `name`, `email`, `phone`, `password`, `address`, `kiosk`, `created`) VALUES
(169, 'Doctor', 'Swadesh Behera', 'swadesh@gmail.com', '1234567890', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', '4092 Furth Circle', 'K001', '2014-08-31 18:21:20'),
(170, 'Doctor', 'Ipsita Sahoo', 'ipsita@gmail.com', '1111111111', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', '2, rue du Commerce', 'K005', '2014-08-31 18:30:58'),
(171, 'Caregiver', 'Trisha Tamanna Priyadarsini', 'trisha@gmail.com', '2222222222', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', 'C/ Moralzarzal, 86', 'K001', '2014-08-31 18:32:03'),
(172, 'Doctor', 'Sai Rimsha Dev', 'rimsha@gmail.com', '3333333333', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', '897 Long Airport Avenue', 'K004', '2014-08-31 20:34:21'),
(173, 'Caregiver', 'Satwik Mohanty', 'satwik@gmail.com', '4444444444', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', 'Lyonerstr. 34', 'K005', '2014-08-31 20:36:02'),
(174, 'Caregiver', 'Tapaswini Sahoo', 'linky@gmail.com', '5555555555', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', 'ul. Filtrowa 68', 'K004', '2014-08-31 20:44:54'),
(175, 'Doctor', 'Manas Ranjan Subudhi', 'manas@gmail.com', '6666666666', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', '5677 Strong St.', 'K001', '2014-08-31 20:45:08'),
(178, 'Admin', 'AngularCode Administrator', 'admin@admin.com', '0000000000', '$2a$10$0fe500de3a2271bb249c3u9kAEvGKmZvW3kWcStt9NFov021vpIwS', 'C/1052, Bangalore', 'K001', '2014-08-31 21:00:26');

--
-- Table structure for table `district_details`
--

CREATE TABLE IF NOT EXISTS `district_details` (
  `did` varchar(5) NOT NULL,
  `dcode` varchar(5) NOT NULL,
  `dname` varchar(50) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;



--
-- Dumping data for table `district_details`
--

INSERT INTO `district_details` (`did`, `dcode`, `dname`) VALUES
('D001', 'HGL', 'Hoogly'),
('D002', 'HWH', 'Howrah'),
('D003', 'BIR', 'Birbhum'),
('D004', 'BUR', 'Burdwan'),
('D005', 'KOL', 'Kolkata');


--
-- Table structure for table `kiosk_details`
--

CREATE TABLE IF NOT EXISTS `kiosk_details` (
  `kid` varchar(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  PRIMARY KEY (`kid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;


--
-- Dumping data for table `kiosk_details`
--

INSERT INTO `kiosk_details` (`kid`, `name`, `district`) VALUES
('K001', 'Kiosk1', 'HGL'),
('K002', 'Kiosk2', 'HWH'),
('K003', 'Kiosk3', 'HWH'),
('K004', 'Kiosk4', 'HWH'),
('K005', 'Kiosk5', 'BIR'),
('K006', 'Kiosk6', 'BUR'),
('K007', 'Kiosk7', 'BIR'),
('K008', 'Kiosk8', 'BUR'),
('K009', 'Kiosk9', 'KOL');

--
-- Table structure for table `patient_id_count`
--

CREATE TABLE IF NOT EXISTS `patient_id_count` (
  `patient_id` int(5) NOT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_id_count`
--

INSERT INTO `patient_id_count` (`patient_id`) VALUES
(1000);


--
-- Table structure for table `patient_details`
--

CREATE TABLE IF NOT EXISTS `patient_details` (
  `pid` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(3) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `payment` float(11) NOT NULL,
  `createdby` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;


--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`pid`, `name`, `age`, `phone`, `payment`, `createdby`) VALUES
('HGLK001P1', 'Animesh Biswas', 23, '9023434367', 200, 171),
('HWHK004P2', 'Sritama Gupta', 52, '9988776655', 200, 174),
('HGLK001P3', 'Sudesh Roy', 28, '9323434367', 200, 171);


--
-- Table structure for table `patient_reports`
--

CREATE TABLE IF NOT EXISTS `patient_reports` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(50) NOT NULL,
  `pulse` varchar(3) NOT NULL,
  `bp` varchar(10) NOT NULL,
  `temp` varchar(3) NOT NULL,
  `oxygen` varchar(3) NOT NULL,
  `soundfile` longblob,
  `sfiletype` varchar(50) NOT NULL,
  `ecgfile` longblob,
  `ecgfiletype` varchar(50) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `createdby` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1000;

--
-- Table structure for table `patient_prescriptions`
--

CREATE TABLE IF NOT EXISTS `patient_prescriptions` (
  `prid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(50) NOT NULL,
  `prescription` varchar(5000000) NOT NULL,
  `createdby` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`prid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1000;


--
-- Table structure for table `patient_assignments`
--

CREATE TABLE IF NOT EXISTS `patient_assignments` (
  `paid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(50) NOT NULL,
  `docid` int(11) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Pending',
  `createdby` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`paid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1000;

--
-- Dumping data for table `patient_assignments`
-- --
-- INSERT INTO `patient_assignments` (`pid`, `docid`) VALUES
-- ('HGLK001P1', 169)
