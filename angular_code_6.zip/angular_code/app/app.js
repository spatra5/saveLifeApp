var app = angular.module('myApp', ['ngRoute', 'ngAnimate', 'toaster']);

app.config(['$routeProvider',
  function ($routeProvider) {
        $routeProvider.
        when('/login', {
            title: 'Login',
            templateUrl: 'partials/login.html',
            controller: 'authCtrl'
        })
            .when('/logout', {
                title: 'Logout',
                templateUrl: 'partials/login.html',
                controller: 'logoutCtrl'
            })
            .when('/signup', {
                title: 'Signup',
                templateUrl: 'partials/signup.html',
                controller: 'authCtrl'
            })
            .when('/dashboard', {
                title: 'Dashboard',
                templateUrl: 'partials/dashboard.html',
                controller: 'authCtrl'
            })
            .when('/patient', {
                title: 'Patient Details',
                templateUrl: 'partials/patient.html',
                controller: 'authCtrl'
            })
            .when('/home', {
                title: 'Home',
                templateUrl: 'partials/home.html',
                controller: 'authCtrl',
            })
            .when('/', {
                title: 'Login',
                templateUrl: 'partials/login.html',
                controller: 'authCtrl',
                role: '0'
            })
            .otherwise({
                redirectTo: '/login'
            });
  }])
    .run(function ($rootScope, $location, Data) {
        $rootScope.$on("$routeChangeStart", function (event, next, current) {
            $rootScope.authenticated = false;
            Data.get('session').then(function (results) {
                if (results.uid) {
                    $rootScope.authenticated = true;
                    $rootScope.uid = results.uid;
                    $rootScope.name = results.name;
                    $rootScope.email = results.email;
                    $rootScope.utype = results.utype;
                    $rootScope.kiosk = results.kiosk;

                    var nextUrl = next.$$route.originalPath;
                    if (nextUrl == '/signup' && results.utype != 'Admin') {
                      $location.path("/dashboard");
                    }
                } else {
                    $location.path("/login");
                    // var nextUrl = next.$$route.originalPath;
                    // if (nextUrl == '/signup' || nextUrl == '/login') {
                    //
                    // } else {
                    //     $location.path("/login");
                    // }
                }
            });
        });
    });


    app.directive('fileModel', ['$parse', function ($parse) {
            return {
               restrict: 'A',
               link: function(scope, element, attrs) {
                  var model = $parse(attrs.fileModel);
                  var modelSetter = model.assign;
                  element.bind('change', function(){
                     scope.$apply(function(){
                        modelSetter(scope, element[0].files[0]);
                     });
                  });
               }
            };
         }]);
