app.controller('authCtrl', function ($scope, $rootScope, $routeParams, $location, $http, Data) {
    //initially set those objects to null to avoid undefined error
    $scope.login = {};
    $scope.signup = {};

    $scope.doLogin = function (customer) {
        Data.post('login', {
            customer: customer
        }).then(function (results) {
            Data.toast(results);
            if (results.status == "success") {
                $location.path('home');
            }
        });
    };
    $scope.userTypeList = ['Caregiver','Doctor'];

    $scope.signup = {email:'',password:'',name:'',phone:'',address:''};
    $scope.signup.utype = angular.copy($scope.userTypeList[0]);
    $scope.signup.kiosk = '';
    $scope.signUp = function (customer) {
        Data.post('signUp', {
            customer: customer
        }).then(function (results) {
            Data.toast(results);
            if (results.status == "success") {
                $location.path('home');
            }
        });
    };
    $scope.logout = function () {
        Data.get('logout').then(function (results) {
            Data.toast(results);
            $location.path('login');
        });
    };

    $scope.addPatient = function (patient) {
        Data.post('patient', {
            patient: patient
        }).then(function (results) {
            Data.toast(results);
        });
    };

    $scope.newPatient = {
      name: 'Soma',
      age: 34,
      phone: Math.round(Math.random() * 10000000000, 10),
      kid: 'K001',
      dcode:'HGL'
    };
    //$scope.addPatient($scope.newPatient);

    $scope.getAllKiosk = function () {
      var url = 'kiosks';
      Data.get(url).then(function (results) {
          $scope.kiosksList = results;
      });
    };
    $scope.userKiosk = null;
    $scope.getKiosk = function (kid) {
      if($scope.userKiosk === null) {
        var url = 'kiosk?kid=' + kid;
        Data.get(url).then(function (results) {
            $scope.userKiosk = {
              id: kid,
              details: results
            };

        });
      }
    };

    $scope.patientsList = null;
    $scope.getPatients = function (kid) {
      if($scope.patientsList === null) {
        var url = 'patients?kid=' + kid;
        Data.get(url).then(function (results) {
            $scope.patientsList = results;
        });
      }
    };

    $scope.doctorsList = null;
    $scope.getDoctors = function (kid) {
      if($scope.doctorsList === null) {
        var url = 'doctors?kid=' + kid;
        Data.get(url).then(function (results) {
            $scope.doctorsList = results;
        });
      }
    };

    $scope.caregiversList = null;
    $scope.getCaregivers = function (kid) {
      if($scope.caregiversList === null) {
        var url = 'caregivers?kid=' + kid;
        Data.get(url).then(function (results) {
            $scope.caregiversList = results;
        });
      }
    };

    $scope.getReports = function (pid) {
      var url = 'reports?pid=' + pid;
      Data.get(url).then(function (results) {
          console.log('patientReportsList', results);
          $scope.patientReportsList = results;
      });
    };
    $scope.newReport = {
      report: '',
      pfile: '',
      ecgfile: ''
    };

    $scope.addReport = function (pid) {
      console.log('Add report to', pid, $scope.newReport.pfile);
      if($scope.newReport.pfile === '' || $scope.newReport.pfile.type.indexOf("audio/") === -1) {
        $scope.ptReportError = 'Please select an audio file for Heart Sound.';
      }
      else if($scope.newReport.ecgfile === '' || $scope.newReport.ecgfile.type.indexOf("image/") === -1) {
        $scope.ptReportError = 'Please select an image file for ECG.';
      }
      else if($scope.newReport.pfile.size/1024/1024 > 10) {
        $scope.ptReportError = 'Please select an audio file of size upto 10MB.';
      }
      else if($scope.newReport.ecgfile.size/1024/1024 > 10) {
        $scope.ptReportError = 'Please select an image file of size upto 10MB.';
      }
      else {
        $scope.ptReportError = '';
        var report = {
          pid: pid,
          report: $scope.newReport.report
        };

        Data.upload('report', {
            report: report
        },$scope.newReport.pfile, $scope.newReport.ecgfile).then(function (results) {
          $scope.newReport = {
            report: '',
            pfile: '',
            ecgfile: ''
          };
          Data.toast(results);
        });
      }
    };

    $scope.navigatePatient = function (patient) {
      $rootScope.currentPatient = patient;
      $location.path('patient');
    };

    $scope.initPatient = function () {
      if(!$rootScope.currentPatient) {
        $location.path('dashboard');
      }
    };

    $scope.downloadFile = function (type, fileId) {
      var url = 'report?rid=' + fileId;
      if(type === 'image') {
        Data.get(url).then(function (results) {
            $scope.reportImage = results;
        });
      }
    };

    // if (results.status == "success") {
    //     $location.path('home');
    // }
    // $scope.init = function () {
    //   console.log('$r', $rootScope.kiosk);
    //   if($rootScope.kiosk) {
    //     $scope.getKiosk($rootScope.kiosk);
    //   }
    // };
});
